
import './App.css'

function Card ({img, month, description}) {
  return (
      <div className="card">
      <img src={img}></img>
      <h2>{month}</h2>
      <p>{description}</p>
      </div>
  )
}

function App() {


  return (
    <>
      <h1>Blog de 5to y 6to</h1>
      <div className="card-list">
        <Card img='./src/assets/Agosto.jpeg' month='Agosto' description='Regreso a Puebla'></Card>
        <Card img='./src/assets/Septiembre.jpeg' month='Septiembre' description='Descubriendo personas'></Card>
        <Card img='./src/assets/Octubre.jpeg' month='Octubre' description='Muy variado para un titulo descriptivo'></Card>
        <Card img='./src/assets/Noviembre.jpeg' month='Noviembre' description='Halloween y Nutrini'></Card>
        <Card img='./src/assets/Diciembre.jpeg' month='Diciembre' description='Vacaciones de invierno'></Card>
        <Card img='./src/assets/Enero.jpeg' month='Enero' description='Vacaciones en Atlixco'></Card>
        <Card img='./src/assets/Febrero.jpeg' month='Febrero' description='San Valentin y más'></Card>
      </div>


      

    </>
  )
}

export default App

