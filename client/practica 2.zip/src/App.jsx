
import './App.css'
import {entries} from './data.js'
import {CardList} from './assets/components/Cards.jsx'
import {useState} from 'react'

function App() {
  const [filteredText, setFilteredText] = useState('');

  function handleChange(e){
    setFilteredText(e.target.value);
  }

  return (
    <>
      <h1>Blog de 5to y 6to</h1>
        <div className='filter'>  
          <p>Buscar: </p>
          <input type='text' value={filteredText} onChange={handleChange}></input>
        </div>
      <CardList entries={entries} filteredText={filteredText}></CardList>
    </>
  )
}

export default App

