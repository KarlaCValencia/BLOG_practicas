function Home() {
  return <h1>Bienvenido al inicio</h1>
}

export default Home