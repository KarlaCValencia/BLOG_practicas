export function CardList({entries, filteredText}) {
  const cards = entries.map(entry => entry.month.includes(filteredText) && <Card id={entry.id} img={entry.img} month={entry.month} description={entry.description}></Card>)
  return (
    <div className='card-list'>
      {cards}
    </div>
  )
}

export function Card ({id, img, month, description}) {
  return (
      <div className="card" key={id}>
      <img src={img}></img>
      <h2>{month}</h2>
      <p>{description}</p>
      </div>
  )
}