function Contact() {
  return <h1>Página de contacto</h1>
}

export default Contact