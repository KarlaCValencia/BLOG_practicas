import './App.css'
import { Routes, Route, Link } from 'react-router'
import Home from './Home.jsx'
import Blog from './Blog.jsx'
import Contact from './Contact.jsx'

function App() {
  return (
    <>
      <nav>
        <Link to="/">Inicio</Link>
        <Link to="/blog">Blog</Link>
        <Link to="/contacto">Contacto</Link>
      </nav>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/contacto" element={<Contact />} />
      </Routes>
    </>
  )
}

export default App