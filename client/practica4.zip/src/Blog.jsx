import './App.css'
import { useState } from "react"
import { entries } from "./data.js"
import { CardList } from "./assets/components/Cards.jsx"

function Blog() {
  const [filteredText, setFilteredText] = useState('')

  function handleChange(e) {
    setFilteredText(e.target.value)
  }

  return (
    <>
      <h1>Blog de 5to y 6to</h1>
      <div className='filter'>
        <p>Buscar: </p>
        <input type='text' value={filteredText} onChange={handleChange} />
      </div>
      <CardList entries={entries} filteredText={filteredText} />
    </>
  )
}

export default Blog